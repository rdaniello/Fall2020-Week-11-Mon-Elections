### Exercise for tooltip plot (10 points)

Make the same plot in Example 01 for US State votes history <br>

<b>State names</b> for each <b>fips</b> is available in the <i>"2020_US_County_Level_Presidential_Results.csv"</i>

1. Aggregate results (using pandas, excel or d3.group) to get state values
2. Use Geojson, or Topojson for states
3. Add trend line as done in the example
